import { combineReducers } from "redux";

import records from "./records";

export default combineReducers({ records: records });
